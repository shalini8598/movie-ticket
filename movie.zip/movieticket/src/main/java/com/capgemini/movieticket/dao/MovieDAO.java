package com.capgemini.movieticket.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.capgemini.movieticket.bean.Movie;
import com.capgemini.movieticket.bean.Show;

public class MovieDAO implements IMovieDAO {
	Map<Integer,Movie> x = new HashMap<Integer,Movie>();
Movie movieObject=new Movie();
//Show showObject;
	public Movie addMovie(Movie obj) {
		Movie ticket = null;
//		 obj.map.put(obj.getMovieId(), obj);
	  //obj.movieGenre.add(showObject);
		x.put(obj.getMovieId(), obj);
	  
		 ticket =obj;
		return ticket;
	}

	public boolean deleteMovie(int movieId) {
		boolean flag = false;
		Movie delete = x.remove( movieId);
		if(delete!=null) {
			flag = true;
		}
   		return flag;
	}
//	public void viewMovies() {
//		Set<Integer>set = movieObject.map.keySet();
//		Iterator it = set.iterator();
//		while(it.hasNext()) {                  
//			Integer key = (Integer) it.next();
//			System.out.println("MovieId - "+ key + " " + " MovieName - " + movieObject.map.get(key));
//		}
	
	public void viewMovies() {
Collection<Movie>	col=	x.values();
List<Movie> list = new ArrayList<Movie>(col);

for(Movie m:list) {
	System.out.println(m+" ");
		}
		
		
		
		
	}
	

}
