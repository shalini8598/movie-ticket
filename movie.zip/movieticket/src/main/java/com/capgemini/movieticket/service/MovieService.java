package com.capgemini.movieticket.service;

import com.capgemini.movieticket.bean.Movie;
import com.capgemini.movieticket.dao.MovieDAO;
import com.capgemini.movieticket.exception.InValidIdException;
import com.capgemini.movieticket.exception.InValidNameException;

public class MovieService implements IMovieService {

	MovieDAO dao = new MovieDAO();

	public Movie addMovie(Movie obj) {
		return dao.addMovie(obj);
	}

	public Boolean deleteMovie(int movieId) {
		return dao.deleteMovie(movieId);
	}
	public void viewMovies() {
		dao.viewMovies();
	}

	public static boolean isValidMovieId(int movieId) {
		String id = movieId + "";
		boolean validMovieId = id.matches("[3][0-9]{3}");
		if (validMovieId == false) {
			try {
				throw new InValidIdException("Invalid MovieId");
			} catch (InValidIdException e) {
			}
		}
		return validMovieId;

	}

	public static boolean isValidMovieName(String movieName) {
		boolean validMovieName = false;
		validMovieName = movieName.matches("[A-Z][a-z]+");
		if (validMovieName == false) {
			try {
				throw new InValidNameException("InValid MovieName");
			} catch (InValidNameException e) {
			}
		}
		return validMovieName;

	}

	public static boolean isValidMovieDirector(String movieDirector) {
		boolean validMovieDirector = false;
		validMovieDirector = movieDirector.matches("[A-Z][a-z]+");
		if (validMovieDirector == false) {
			try {
				throw new InValidNameException("InValid MovieDirector");
			} catch (InValidNameException e) {

			}
		}

		return validMovieDirector;
 
	}

	public static boolean movieValidation(Movie obj) {
		boolean flag = false;
		if (isValidMovieId(obj.getMovieId()) && isValidMovieName(obj.getMovieName())
				&& isValidMovieDirector(obj.getMovieDirector())) {
			flag = true;
		}
		return flag;
	}

}

