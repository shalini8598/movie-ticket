package com.capgemini.movieticket.service;

import com.capgemini.movieticket.bean.Movie;

public interface IMovieService {
	Movie addMovie(Movie obj);
	Boolean deleteMovie(int movieId);
	

}
